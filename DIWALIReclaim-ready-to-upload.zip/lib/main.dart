import 'dart:async';
import 'dart:convert';
import 'dart:math' as m;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

const ch = MethodChannel('reclaim/native');
const teal = Color(0xFF0F6B66);
const amber = Color(0xFFE9A92C);

class Ap {
  final String n, p;
  final Color c;
  const Ap(this.n, this.p, this.c);
}

const apps = [
  Ap('Instagram', 'com.instagram.android', Color(0xFFC13584)),
  Ap('YouTube', 'com.google.android.youtube', Color(0xFFD32F2F)),
  Ap('TikTok', 'com.zhiliaoapp.musically', Color(0xFF222B33)),
  Ap('Snapchat', 'com.snapchat.android', Color(0xFFE6B800)),
  Ap('Facebook', 'com.facebook.katana', Color(0xFF1877F2)),
  Ap('X', 'com.twitter.android', Color(0xFF4B5963)),
  Ap('Reddit', 'com.reddit.frontpage', Color(0xFFFF4500)),
  Ap('WhatsApp', 'com.whatsapp', Color(0xFF1E9E5A)),
];

String dk([DateTime? d]) => (d ?? DateTime.now()).toIso8601String().substring(0, 10);
int nowMs() => DateTime.now().millisecondsSinceEpoch;
String fm(int x) => x >= 60 ? '${x ~/ 60}h ${x % 60}m' : '${x}m';

class S extends ChangeNotifier {
  late SharedPreferences sp;
  int goal = 240, dur = 25, fEnd = 0, fLen = 0;
  bool ig = true, yt = true, all = false, strict = false, pUse = false, pAcc = false;
  bool bed = false, bedIg = true, bedYt = true, bedAll = false;
  int bedS = 1350, bedE = 390;
  bool pause = false, wk = false, wkWd = true;
  int wkS = 540, wkE = 1020;
  Set<String> sApps = {'com.instagram.android', 'com.zhiliaoapp.musically', 'com.snapchat.android'};
  Map<String, int> lim = {};
  Set<String> fApps = {'com.instagram.android', 'com.zhiliaoapp.musically'};
  Map<String, List<int>> hist = {};
  List<Map> sess = [];
  List<Map<String, dynamic>> list = [];

  Future<void> load() async {
    sp = await SharedPreferences.getInstance();
    try {
      final j = jsonDecode(sp.getString('st') ?? '{}') as Map;
      goal = j['goal'] ?? 240;
      dur = j['dur'] ?? 25;
      ig = j['ig'] ?? true;
      yt = j['yt'] ?? true;
      all = j['all'] ?? false;
      strict = j['strict'] ?? false;
      bed = j['bed'] ?? false;
      bedIg = j['bedIg'] ?? true;
      bedYt = j['bedYt'] ?? true;
      bedAll = j['bedAll'] ?? false;
      bedS = j['bedS'] ?? 1350;
      bedE = j['bedE'] ?? 390;
      pause = j['pause'] ?? false;
      wk = j['wk'] ?? false;
      wkWd = j['wkWd'] ?? true;
      wkS = j['wkS'] ?? 540;
      wkE = j['wkE'] ?? 1020;
      if (j['sApps'] != null) sApps = Set<String>.from(j['sApps']);
      fEnd = j['fEnd'] ?? 0;
      fLen = j['fLen'] ?? 0;
      lim = Map<String, int>.from(j['lim'] ?? {});
      if (j['fApps'] != null) fApps = Set<String>.from(j['fApps']);
      hist = Map<String, dynamic>.from(j['hist'] ?? {}).map((k, v) => MapEntry(k, List<int>.from(v)));
      sess = List<Map>.from(j['sess'] ?? []);
    } catch (_) {}
  }

  Future<void> save() async {
    sp.setString('st', jsonEncode({
      'goal': goal, 'dur': dur, 'ig': ig, 'yt': yt, 'all': all, 'strict': strict,
      'lim': lim, 'fApps': fApps.toList(), 'fEnd': fEnd, 'fLen': fLen, 'hist': hist, 'sess': sess,
      'bed': bed, 'bedIg': bedIg, 'bedYt': bedYt, 'bedAll': bedAll, 'bedS': bedS, 'bedE': bedE,
      'pause': pause, 'wk': wk, 'wkWd': wkWd, 'wkS': wkS, 'wkE': wkE, 'sApps': sApps.toList(),
    }));
    try {
      await ch.invokeMethod('rules', jsonEncode({
        'all': all, 'apps': apps.map((a) => a.p).toList(), 'fEnd': fEnd,
        'fApps': fApps.toList(), 'lim': lim, 'ig': ig, 'yt': yt,
        'pause': pause,
        'wk': {'on': wk, 's': wkS, 'e': wkE, 'wd': wkWd, 'apps': sApps.toList()},
        'bed': {'on': bed, 's': bedS, 'e': bedE, 'ig': bedIg, 'yt': bedYt, 'all': bedAll},
      }));
    } catch (_) {}
    notifyListeners();
  }

  int get total => list.fold(0, (a, e) => a + (e['min'] as int));
  int usedOf(String pkg) => list.where((e) => e['pkg'] == pkg).fold(0, (a, e) => a + (e['min'] as int));
  bool get running => fEnd > nowMs();
  bool get bedNow {
    if (!bed) return false;
    final n = DateTime.now();
    final x = n.hour * 60 + n.minute;
    return bedS <= bedE ? (x >= bedS && x < bedE) : (x >= bedS || x < bedE);
  }
  int get streak {
    var n = 0;
    for (var i = 0; i < 30; i++) {
      final v = hist[dk(DateTime.now().subtract(Duration(days: i)))];
      if (v == null || v[0] == 0 || v[0] > goal) break;
      n++;
    }
    return n;
  }

  Future<void> refresh() async {
    try {
      final p = Map<String, dynamic>.from(await ch.invokeMethod('perms'));
      pUse = p['usage'] == true;
      pAcc = p['acc'] == true;
      if (pUse) {
        final l = await ch.invokeMethod('usage') as List;
        list = l.map((e) => Map<String, dynamic>.from(e)).toList()
          ..sort((a, b) => (b['min'] as int).compareTo(a['min'] as int));
      }
    } catch (_) {}
    hist.putIfAbsent(dk(), () => [0, 0])[0] = total;
    checkFocus();
    await save();
  }

  void start() {
    fLen = dur;
    fEnd = nowMs() + dur * 60000;
    save();
  }

  void finish(bool done) {
    final mins = done ? fLen : ((nowMs() - (fEnd - fLen * 60000)) / 60000).floor();
    if (mins > 0) {
      hist.putIfAbsent(dk(), () => [0, 0])[1] += mins;
      final d = DateTime.now();
      sess.add({'m': mins, 't': '${d.hour}:${d.minute.toString().padLeft(2, '0')}'});
    }
    fEnd = 0;
    fLen = 0;
    save();
  }

  void checkFocus() {
    if (fLen > 0 && fEnd <= nowMs()) finish(true);
  }

  void resetToday() {
    hist[dk()] = [total, 0];
    sess.clear();
    save();
  }

  void resetSettings() {
    goal = 240; dur = 25; ig = true; yt = true; all = false; strict = false;
    bed = false; bedIg = true; bedYt = true; bedAll = false; bedS = 1350; bedE = 390;
    pause = false; wk = false; wkWd = true; wkS = 540; wkE = 1020;
    sApps = {'com.instagram.android', 'com.zhiliaoapp.musically', 'com.snapchat.android'};
    lim = {};
    fApps = {'com.instagram.android', 'com.zhiliaoapp.musically'};
    save();
  }

  void clearAll() {
    hist = {};
    sess = [];
    fEnd = 0;
    fLen = 0;
    resetSettings();
  }
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final s = S();
  await s.load();
  runApp(ReclaimApp(s));
}

ThemeData _theme(Brightness b) =>
    ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: teal, brightness: b));

class ReclaimApp extends StatelessWidget {
  final S s;
  const ReclaimApp(this.s, {super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Reclaim',
        debugShowCheckedModeBanner: false,
        themeMode: ThemeMode.system,
        theme: _theme(Brightness.light),
        darkTheme: _theme(Brightness.dark),
        home: Home(s),
      );
}

class Home extends StatefulWidget {
  final S s;
  const Home(this.s, {super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> with WidgetsBindingObserver {
  int tab = 0;
  Timer? t;
  S get s => widget.s;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    s.addListener(() {
      if (mounted) setState(() {});
    });
    s.refresh();
    t = Timer.periodic(const Duration(seconds: 1), (x) {
      if (s.fLen > 0) {
        s.checkFocus();
        if (mounted) setState(() {});
      }
      if (x.tick % 30 == 0) s.refresh();
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState st) {
    if (st == AppLifecycleState.resumed) s.refresh();
  }

  @override
  void dispose() {
    t?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [Today(s), FocusP(s), Limits(s), Bedtime(s), Week(s)];
    return Scaffold(
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.timelapse), label: 'Today'),
          NavigationDestination(icon: Icon(Icons.center_focus_strong), label: 'Focus'),
          NavigationDestination(icon: Icon(Icons.lock_clock), label: 'Limits'),
          NavigationDestination(icon: Icon(Icons.event_note), label: 'Schedules'),
          NavigationDestination(icon: Icon(Icons.bar_chart), label: 'Week'),
        ],
      ),
    );
  }
}

// ---------- shared widgets ----------
Widget card(Widget c, {EdgeInsets p = const EdgeInsets.all(16)}) =>
    Card(margin: const EdgeInsets.only(bottom: 12), child: Padding(padding: p, child: c));

Widget h(String t) => Padding(
    padding: const EdgeInsets.fromLTRB(4, 12, 4, 8),
    child: Text(t, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)));

Widget stat(String a, String b) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(a, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
      Text(b),
    ]);

Future<void> confirm(BuildContext c, String msg, VoidCallback ok) async {
  final r = await showDialog<bool>(
    context: c,
    builder: (x) => AlertDialog(
      title: const Text('Are you sure?'),
      content: Text(msg),
      actions: [
        TextButton(onPressed: () => Navigator.pop(x, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(x, true), child: const Text('Reset')),
      ],
    ),
  );
  if (r == true) ok();
}

class RingW extends StatelessWidget {
  final double pct;
  final Color color;
  final Widget child;
  const RingW(this.pct, this.color, this.child, {super.key});
  @override
  Widget build(BuildContext context) => SizedBox(
        width: 220,
        height: 220,
        child: Stack(alignment: Alignment.center, children: [
          CustomPaint(
              size: const Size(220, 220),
              painter: _RingPaint(pct.clamp(0.0, 1.0).toDouble(), color, Theme.of(context).colorScheme.surfaceContainerHighest)),
          child,
        ]),
      );
}

class _RingPaint extends CustomPainter {
  final double pct;
  final Color col, track;
  _RingPaint(this.pct, this.col, this.track);
  @override
  void paint(Canvas c, Size z) {
    final r = Rect.fromCircle(center: Offset(z.width / 2, z.height / 2), radius: 96);
    final p = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 14
      ..strokeCap = StrokeCap.round
      ..color = track;
    c.drawArc(r, 0, m.pi * 2, false, p);
    p.color = col;
    c.drawArc(r, -m.pi / 2, m.pi * 2 * pct, false, p);
  }

  @override
  bool shouldRepaint(_RingPaint o) => o.pct != pct || o.col != col || o.track != track;
}

// Logo: almost-closed ring with an amber dot in the gap.
class LogoW extends StatelessWidget {
  final double size;
  const LogoW(this.size, {super.key});
  @override
  Widget build(BuildContext context) => CustomPaint(size: Size(size, size), painter: _LogoPaint());
}

class _LogoPaint extends CustomPainter {
  @override
  void paint(Canvas c, Size z) {
    final r = z.width * 0.38;
    final o = Offset(z.width / 2, z.height / 2);
    final p = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = z.width * 0.1
      ..strokeCap = StrokeCap.round
      ..color = teal;
    c.drawArc(Rect.fromCircle(center: o, radius: r), -0.1745, 5.585, false, p);
    final a = -m.pi / 6;
    c.drawLine(o, Offset(o.dx + r * 0.45 * m.cos(a), o.dy + r * 0.45 * m.sin(a)), p..strokeWidth = z.width * 0.07);
    c.drawCircle(Offset(o.dx + r * m.cos(a), o.dy + r * m.sin(a)), z.width * 0.08, Paint()..color = amber);
  }

  @override
  bool shouldRepaint(_LogoPaint o) => false;
}

// ---------- Today ----------
class Today extends StatelessWidget {
  final S s;
  const Today(this.s, {super.key});
  @override
  Widget build(BuildContext context) {
    final t = s.total, left = s.goal - t;
    final top = s.list.take(8).toList();
    final mx = top.isEmpty ? 1 : (top.first['min'] as int);
    return RefreshIndicator(
      onRefresh: s.refresh,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        const Row(children: [
          LogoW(36),
          SizedBox(width: 10),
          Text('Reclaim', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
        ]),
        const SizedBox(height: 12),
        if (!s.pUse || !s.pAcc)
          card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Finish setup', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            const SizedBox(height: 6),
            const Text('Reclaim needs two permissions to track and block apps. Everything stays on your phone.'),
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Usage access'),
              subtitle: const Text('Reads time spent in each app'),
              trailing: s.pUse
                  ? const Icon(Icons.check_circle, color: teal)
                  : FilledButton(onPressed: () => ch.invokeMethod('openUsage'), child: const Text('Allow')),
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Accessibility'),
              subtitle: const Text('Closes blocked apps, Reels and Shorts'),
              trailing: s.pAcc
                  ? const Icon(Icons.check_circle, color: teal)
                  : FilledButton(onPressed: () => ch.invokeMethod('openA11y'), child: const Text('Allow')),
            ),
          ])),
        card(Center(
            child: RingW(
                t / s.goal,
                teal,
                Column(mainAxisSize: MainAxisSize.min, children: [
                  Text(fm(t), style: const TextStyle(fontSize: 44, fontWeight: FontWeight.w800)),
                  const Text('whole phone today'),
                  Text(left >= 0 ? '${fm(left)} under goal' : '${fm(-left)} over goal'),
                ])))),
        Row(children: [
          Expanded(child: card(stat(fm(s.hist[dk()]?[1] ?? 0), 'focused today'))),
          const SizedBox(width: 12),
          Expanded(child: card(stat('${s.streak}', 'day streak'))),
        ]),
        h('Most used today'),
        card(
            top.isEmpty
                ? const Text('No usage yet. Allow usage access above, then pull down to refresh.')
                : Column(
                    children: top
                        .map((e) => Padding(
                              padding: const EdgeInsets.symmetric(vertical: 6),
                              child: Row(children: [
                                CircleAvatar(
                                    radius: 16,
                                    backgroundColor: teal.withOpacity(.15),
                                    child: Text((e['label'] as String).substring(0, 1))),
                                const SizedBox(width: 12),
                                Expanded(
                                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                                    Flexible(child: Text(e['label'] as String, overflow: TextOverflow.ellipsis)),
                                    Text(fm(e['min'] as int)),
                                  ]),
                                  const SizedBox(height: 6),
                                  ClipRRect(
                                      borderRadius: BorderRadius.circular(4),
                                      child: LinearProgressIndicator(value: (e['min'] as int) / mx, minHeight: 6)),
                                ])),
                              ]),
                            ))
                        .toList())),
        h('Daily goal: ${fm(s.goal)}'),
        card(Slider(
            value: s.goal.toDouble(),
            min: 60,
            max: 480,
            divisions: 28,
            label: fm(s.goal),
            onChanged: (v) {
              s.goal = v.round();
              s.save();
            }), p: const EdgeInsets.symmetric(horizontal: 8, vertical: 4)),
      ]),
    );
  }
}

// ---------- Focus ----------
class FocusP extends StatelessWidget {
  final S s;
  const FocusP(this.s, {super.key});
  @override
  Widget build(BuildContext context) {
    final run = s.running;
    final left = run ? ((s.fEnd - nowMs()) / 1000).ceil() : s.dur * 60;
    final pct = run ? 1 - left / (s.fLen * 60) : 0.0;
    final txt = '${left ~/ 60}:${(left % 60).toString().padLeft(2, '0')}';
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Focus', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
      const SizedBox(height: 12),
      card(Center(
          child: RingW(
              pct,
              amber,
              Column(mainAxisSize: MainAxisSize.min, children: [
                Text(txt, style: const TextStyle(fontSize: 44, fontWeight: FontWeight.w800)),
                Text(run ? 'stay with it' : 'ready'),
              ])))),
      h('Length'),
      Wrap(spacing: 8, children: [
        for (final d in [15, 25, 45, 60])
          ChoiceChip(
              label: Text('$d min'),
              selected: s.dur == d,
              onSelected: run
                  ? null
                  : (_) {
                      s.dur = d;
                      s.save();
                    }),
      ]),
      h('Apps to block'),
      Wrap(spacing: 8, children: [
        FilterChip(
            label: const Text('All apps'),
            selected: s.fApps.length == apps.length,
            onSelected: run
                ? null
                : (v) {
                    s.fApps = v ? apps.map((a) => a.p).toSet() : <String>{};
                    s.save();
                  }),
        for (final a in apps)
          FilterChip(
              label: Text(a.n),
              selected: s.fApps.contains(a.p),
              onSelected: run
                  ? null
                  : (v) {
                      v ? s.fApps.add(a.p) : s.fApps.remove(a.p);
                      s.save();
                    }),
      ]),
      SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Strict mode'),
          subtitle: const Text('You can’t end a session early'),
          value: s.strict,
          onChanged: run
              ? null
              : (v) {
                  s.strict = v;
                  s.save();
                }),
      const SizedBox(height: 8),
      if (run)
        OutlinedButton(
            onPressed: s.strict ? null : () => s.finish(false),
            child: Text(s.strict ? 'Strict mode is on' : 'End session'))
      else
        FilledButton(
            onPressed: s.fApps.isEmpty ? null : s.start,
            child: Text(s.fApps.isEmpty ? 'Pick apps to block' : 'Start ${s.dur}-minute focus')),
      h('Recent sessions'),
      card(
          s.sess.isEmpty
              ? const Text('No sessions yet. Start one above.')
              : Column(
                  children: s.sess.reversed
                      .take(5)
                      .map((e) => Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [Text('${e['m']} min focus'), Text('${e['t']}')])))
                      .toList())),
    ]);
  }
}

// ---------- Limits ----------
class Limits extends StatelessWidget {
  final S s;
  const Limits(this.s, {super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Limits', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
      h('Block all'),
      card(
          SwitchListTile(
              title: const Text('Block all apps'),
              subtitle: Text(s.all ? 'Every listed app is blocked' : 'One tap to block every app below'),
              value: s.all,
              onChanged: (v) {
                s.all = v;
                s.save();
              }),
          p: EdgeInsets.zero),
      h('Mindful pause'),
      card(
          SwitchListTile(
              title: const Text('Pause before opening'),
              subtitle: const Text('A 10-second breath before any app on your list opens'),
              value: s.pause,
              onChanged: (v) {
                s.pause = v;
                s.save();
              }),
          p: EdgeInsets.zero),
      h('Reels and Shorts'),
      card(
          Column(children: [
            SwitchListTile(
                title: const Text('Instagram Reels'),
                subtitle: const Text('Leaves Reels, keeps feed and DMs'),
                value: s.ig,
                onChanged: (v) {
                  s.ig = v;
                  s.save();
                }),
            SwitchListTile(
                title: const Text('YouTube Shorts'),
                subtitle: const Text('Leaves Shorts, keeps normal videos'),
                value: s.yt,
                onChanged: (v) {
                  s.yt = v;
                  s.save();
                }),
          ]),
          p: EdgeInsets.zero),
      h('App limits'),
      for (final a in apps)
        card(
            Column(children: [
              SwitchListTile(
                  title: Text(a.n),
                  subtitle: Text(s.lim.containsKey(a.p)
                      ? '${fm(s.usedOf(a.p))} of ${fm(s.lim[a.p]!)} today'
                      : 'No limit'),
                  value: s.lim.containsKey(a.p),
                  onChanged: (v) {
                    v ? s.lim[a.p] = 45 : s.lim.remove(a.p);
                    s.save();
                  }),
              if (s.lim.containsKey(a.p))
                Slider(
                    value: s.lim[a.p]!.toDouble(),
                    min: 10,
                    max: 180,
                    divisions: 34,
                    label: fm(s.lim[a.p]!),
                    onChanged: (v) {
                      s.lim[a.p] = v.round();
                      s.save();
                    }),
            ]),
            p: EdgeInsets.zero),
    ]);
  }
}

// ---------- Week ----------
class Week extends StatelessWidget {
  final S s;
  const Week(this.s, {super.key});
  @override
  Widget build(BuildContext context) {
    final days = List.generate(7, (i) => DateTime.now().subtract(Duration(days: 6 - i)));
    final v = days.map((d) => s.hist[dk(d)] ?? [0, 0]).toList();
    final mx = v.fold<int>(1, (a, e) => m.max(a, e[0] + e[1]));
    final avg = v.fold<int>(0, (a, e) => a + e[0]) ~/ 7;
    final foc = v.fold<int>(0, (a, e) => a + e[1]);
    const L = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('This week', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
      const Text('Teal is screen time, amber is focus.'),
      const SizedBox(height: 12),
      card(SizedBox(
          height: 150,
          child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
            for (var i = 0; i < 7; i++)
              Expanded(
                  child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 5),
                      child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                        Container(
                            height: 120 * v[i][1] / mx,
                            decoration: const BoxDecoration(
                                color: amber, borderRadius: BorderRadius.vertical(top: Radius.circular(6)))),
                        Container(height: 120 * v[i][0] / mx, color: teal),
                        const SizedBox(height: 4),
                        Text(L[days[i].weekday - 1]),
                      ]))),
          ]))),
      Row(children: [
        Expanded(child: card(stat(fm(avg), 'daily average'))),
        const SizedBox(width: 12),
        Expanded(child: card(stat(fm(foc), 'total focus'))),
      ]),
      Row(children: [
        Expanded(child: card(stat('${s.streak}', 'day streak'))),
        const SizedBox(width: 12),
        Expanded(child: card(stat('${s.sess.length}', 'sessions today'))),
      ]),
      h('Privacy'),
      card(const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Icon(Icons.lock, color: teal), SizedBox(width: 10), Text('Everything stays on your phone', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16))]),
        SizedBox(height: 10),
        Text('No account, no ads, no tracking. Reclaim has no internet permission, so it can’t send your data anywhere.'),
        SizedBox(height: 8),
        Text('Your usage, sessions and settings are stored only on this device and are excluded from cloud backups.'),
        SizedBox(height: 8),
        Text('Accessibility is used only to close blocked apps and Reels or Shorts. It doesn’t read or save what is on your screen.'),
      ])),
      h('Reset'),
      OutlinedButton(
          onPressed: () => confirm(context, 'Clears today’s focus time and sessions.', s.resetToday),
          child: const Text('Reset today')),
      OutlinedButton(
          onPressed: () => confirm(context, 'Restores the goal, limits, blockers and focus options to defaults.', s.resetSettings),
          child: const Text('Reset settings')),
      OutlinedButton(
          onPressed: () => confirm(context, 'Deletes all history, sessions and settings.', s.clearAll),
          child: const Text('Clear all data')),
    ]);
  }
}

// ---------- Bedtime ----------
String tm(int x) {
  final h = x ~/ 60, mm = x % 60;
  final hh = h % 12 == 0 ? 12 : h % 12;
  return '$hh:${mm.toString().padLeft(2, '0')} ${h < 12 ? 'AM' : 'PM'}';
}

class Bedtime extends StatelessWidget {
  final S s;
  const Bedtime(this.s, {super.key});

  Future<void> pickWk(BuildContext c, bool start) async {
    final cur = start ? s.wkS : s.wkE;
    final t = await showTimePicker(context: c, initialTime: TimeOfDay(hour: cur ~/ 60, minute: cur % 60));
    if (t == null) return;
    if (start) {
      s.wkS = t.hour * 60 + t.minute;
    } else {
      s.wkE = t.hour * 60 + t.minute;
    }
    s.save();
  }

  Future<void> pick(BuildContext c, bool start) async {
    final cur = start ? s.bedS : s.bedE;
    final t = await showTimePicker(context: c, initialTime: TimeOfDay(hour: cur ~/ 60, minute: cur % 60));
    if (t == null) return;
    if (start) {
      s.bedS = t.hour * 60 + t.minute;
    } else {
      s.bedE = t.hour * 60 + t.minute;
    }
    s.save();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Schedules', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
      h('Bedtime'),
      Text(!s.bed ? 'Off' : (s.bedNow ? 'Bedtime is on right now.' : 'Starts at ${tm(s.bedS)}.')),
      const SizedBox(height: 12),
      card(
          SwitchListTile(
              title: const Text('Bedtime mode'),
              subtitle: const Text('Turns on by itself every night'),
              value: s.bed,
              onChanged: (v) {
                s.bed = v;
                s.save();
              }),
          p: EdgeInsets.zero),
      card(
          Column(children: [
            ListTile(title: const Text('Starts'), trailing: Text(tm(s.bedS)), onTap: () => pick(context, true)),
            ListTile(title: const Text('Ends'), trailing: Text(tm(s.bedE)), onTap: () => pick(context, false)),
          ]),
          p: EdgeInsets.zero),
      h('During bedtime'),
      card(
          Column(children: [
            SwitchListTile(
                title: const Text('Instagram can’t be opened'),
                subtitle: const Text('The whole app is blocked'),
                value: s.bedIg,
                onChanged: (v) {
                  s.bedIg = v;
                  s.save();
                }),
            SwitchListTile(
                title: const Text('YouTube Shorts locked'),
                subtitle: const Text('Normal videos still work'),
                value: s.bedYt,
                onChanged: (v) {
                  s.bedYt = v;
                  s.save();
                }),
            SwitchListTile(
                title: const Text('Lock the whole phone'),
                subtitle: const Text('Only calls, messages, clock, settings and keyboard still work'),
                value: s.bedAll,
                onChanged: (v) {
                  s.bedAll = v;
                  s.save();
                }),
          ]),
          p: EdgeInsets.zero),
      h('Work or study hours'),
      card(
          Column(children: [
            SwitchListTile(
                title: const Text('Block apps during these hours'),
                subtitle: Text(s.wk ? '${tm(s.wkS)} to ${tm(s.wkE)}' : 'Off'),
                value: s.wk,
                onChanged: (v) {
                  s.wk = v;
                  s.save();
                }),
            ListTile(title: const Text('Starts'), trailing: Text(tm(s.wkS)), onTap: () => pickWk(context, true)),
            ListTile(title: const Text('Ends'), trailing: Text(tm(s.wkE)), onTap: () => pickWk(context, false)),
            SwitchListTile(
                title: const Text('Weekdays only'),
                value: s.wkWd,
                onChanged: (v) {
                  s.wkWd = v;
                  s.save();
                }),
            Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                child: Wrap(spacing: 8, children: [
                  for (final a in apps)
                    FilterChip(
                        label: Text(a.n),
                        selected: s.sApps.contains(a.p),
                        onSelected: (v) {
                          v ? s.sApps.add(a.p) : s.sApps.remove(a.p);
                          s.save();
                        }),
                ])),
          ]),
          p: EdgeInsets.zero),
    ]);
  }
}
