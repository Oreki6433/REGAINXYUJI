package com.reclaim.reclaim

import android.content.Intent
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "reclaim/native").setMethodCallHandler { call, res ->
            when (call.method) {
                "perms" -> res.success(mapOf("usage" to Native.hasUsage(this), "acc" to Native.hasAcc(this)))
                "usage" -> res.success(Native.list(this))
                "rules" -> { Native.save(this, call.arguments as String); res.success(null) }
                "openUsage" -> { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)); res.success(null) }
                "openA11y" -> { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); res.success(null) }
                else -> res.notImplemented()
            }
        }
    }
}
