package com.reclaim.reclaim

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Process
import android.provider.Settings
import org.json.JSONObject
import java.util.Calendar

object Native {
    fun hasUsage(c: Context): Boolean {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val m = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        return m == AppOpsManager.MODE_ALLOWED
    }

    fun hasAcc(c: Context): Boolean {
        val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(c.packageName)
    }

    private fun dayStart(): Long {
        val k = Calendar.getInstance()
        k.set(Calendar.HOUR_OF_DAY, 0); k.set(Calendar.MINUTE, 0)
        k.set(Calendar.SECOND, 0); k.set(Calendar.MILLISECOND, 0)
        return k.timeInMillis
    }

    fun usage(c: Context): Map<String, Long> {
        val u = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val st = u.queryAndAggregateUsageStats(dayStart(), System.currentTimeMillis())
        return st.mapValues { it.value.totalTimeInForeground / 60000 }
    }

    fun list(c: Context): List<Map<String, Any>> {
        val pm = c.packageManager
        return usage(c)
            .filter {
                it.value > 0 && it.key != c.packageName &&
                    !it.key.contains("launcher") && !it.key.contains("systemui") &&
                    pm.getLaunchIntentForPackage(it.key) != null
            }
            .map {
                val label = try { pm.getApplicationInfo(it.key, 0).loadLabel(pm).toString() } catch (e: Exception) { it.key }
                mapOf("pkg" to it.key, "label" to label, "min" to it.value.toInt())
            }
    }

    fun save(c: Context, json: String) {
        c.getSharedPreferences("reclaim", 0).edit().putString("rules", json).apply()
    }

    fun rules(c: Context): JSONObject = try {
        JSONObject(c.getSharedPreferences("reclaim", 0).getString("rules", "{}") ?: "{}")
    } catch (e: Exception) { JSONObject() }
}
