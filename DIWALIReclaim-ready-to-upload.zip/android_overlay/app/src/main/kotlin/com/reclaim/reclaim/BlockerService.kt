package com.reclaim.reclaim

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

class BlockerService : AccessibilityService() {
    private var lastAct = 0L
    private var lastScan = 0L
    private var lastPause = 0L
    private val cache = HashMap<String, Pair<Long, Long>>()

    // View-id keywords that appear only on the Reels / Shorts full-screen player.
    // Apps change these in updates; edit here if blocking stops working.
    private val igKeys = listOf("clips_viewer", "reel_viewer")
    private val ytKeys = listOf("reel_player", "reel_recycler")

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val pkg = e?.packageName?.toString() ?: return
        if (pkg == packageName) return
        val now = System.currentTimeMillis()
        if (now - lastAct < 1200) return
        val r = Native.rules(this)

        if (isBlocked(pkg, r, now)) {
            act("Blocked by Reclaim", GLOBAL_ACTION_HOME, now)
            return
        }
        if (r.optBoolean("pause") && e?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            has(r.optJSONArray("apps"), pkg)) {
            val ok = getSharedPreferences("reclaim", 0).getLong("ok_$pkg", 0L)
            if (now - ok > 300000 && now - lastPause > 12000) {
                lastPause = now
                startActivity(Intent(this, PauseActivity::class.java).putExtra("pkg", pkg)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        if (now - lastScan < 400) return
        val keys = when {
            pkg == "com.instagram.android" && r.optBoolean("ig") -> igKeys
            pkg == "com.google.android.youtube" && (r.optBoolean("yt") || bedYt(r)) -> ytKeys
            else -> return
        }
        lastScan = now
        if (inFeed(rootInActiveWindow, keys)) {
            act(if (keys === igKeys) "Reels blocked" else "Shorts blocked", GLOBAL_ACTION_BACK, now)
        }
    }

    private fun act(msg: String, action: Int, now: Long) {
        lastAct = now
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        performGlobalAction(action)
    }

    private fun has(a: JSONArray?, p: String): Boolean {
        if (a == null) return false
        for (i in 0 until a.length()) if (a.optString(i) == p) return true
        return false
    }

    private fun isBlocked(pkg: String, r: JSONObject, now: Long): Boolean {
        val b = r.optJSONObject("bed")
        if (b != null && b.optBoolean("on") && inBed(b)) {
            if (b.optBoolean("ig") && pkg == "com.instagram.android") return true
            if (b.optBoolean("all") && !allowed(pkg)) return true
        }
        val w = r.optJSONObject("wk")
        if (w != null && w.optBoolean("on") && inWin(w.optInt("s"), w.optInt("e")) &&
            (!w.optBoolean("wd") || weekday()) && has(w.optJSONArray("apps"), pkg)) return true
        if (r.optBoolean("all") && has(r.optJSONArray("apps"), pkg)) return true
        if (r.optLong("fEnd") > now && has(r.optJSONArray("fApps"), pkg)) return true
        val lim = r.optJSONObject("lim")?.optInt(pkg, 0) ?: 0
        if (lim > 0) {
            val c = cache[pkg]
            val used = if (c != null && now - c.first < 20000) c.second else {
                val v = if (Native.hasUsage(this)) (Native.usage(this)[pkg] ?: 0L) else 0L
                cache[pkg] = Pair(now, v)
                v
            }
            if (used >= lim) return true
        }
        return false
    }

    private fun inBed(b: JSONObject): Boolean {
        val c = java.util.Calendar.getInstance()
        val x = c.get(java.util.Calendar.HOUR_OF_DAY) * 60 + c.get(java.util.Calendar.MINUTE)
        val s = b.optInt("s")
        val en = b.optInt("e")
        return if (s <= en) x >= s && x < en else (x >= s || x < en)
    }

    private fun inWin(s: Int, en: Int): Boolean {
        val c = java.util.Calendar.getInstance()
        val x = c.get(java.util.Calendar.HOUR_OF_DAY) * 60 + c.get(java.util.Calendar.MINUTE)
        return if (s <= en) x >= s && x < en else (x >= s || x < en)
    }

    private fun weekday(): Boolean {
        val d = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_WEEK)
        return d != java.util.Calendar.SATURDAY && d != java.util.Calendar.SUNDAY
    }

    private fun bedYt(r: JSONObject): Boolean {
        val b = r.optJSONObject("bed") ?: return false
        return b.optBoolean("on") && b.optBoolean("yt") && inBed(b)
    }

    // Apps that stay usable when "Lock the whole phone" is on.
    private val okWords = listOf("launcher", "systemui", "settings", "dialer", "telecom", "incallui",
        "clock", "inputmethod", "keyboard", "emergency", "contacts", "messaging", "mms")

    private fun allowed(pkg: String) = pkg == packageName || okWords.any { pkg.contains(it) }

    private fun inFeed(root: AccessibilityNodeInfo?, keys: List<String>): Boolean {
        if (root == null) return false
        val q = ArrayDeque<AccessibilityNodeInfo>()
        q.add(root)
        var n = 0
        while (q.isNotEmpty() && n < 500) {
            val x = q.removeFirst()
            n++
            val id = x.viewIdResourceName
            if (id != null && keys.any { id.contains(it) }) return true
            for (i in 0 until x.childCount) x.getChild(i)?.let { q.add(it) }
        }
        return false
    }
}
