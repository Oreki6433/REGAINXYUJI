package com.reclaim.reclaim

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.CountDownTimer
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class PauseActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pkg = intent.getStringExtra("pkg") ?: ""
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.setBackgroundColor(Color.parseColor("#0F1A1F"))
        col.setPadding(64, 64, 64, 64)

        val title = TextView(this)
        title.text = "Take a breath"
        title.textSize = 30f
        title.setTextColor(Color.WHITE)
        title.gravity = Gravity.CENTER

        val sub = TextView(this)
        sub.text = "Do you really want to open this right now?"
        sub.textSize = 16f
        sub.setTextColor(Color.parseColor("#93A7AF"))
        sub.gravity = Gravity.CENTER
        sub.setPadding(0, 16, 0, 32)

        val count = TextView(this)
        count.text = "10"
        count.textSize = 64f
        count.setTextColor(Color.parseColor("#F2B544"))
        count.gravity = Gravity.CENTER
        count.setPadding(0, 0, 0, 32)

        val open = Button(this)
        open.text = "Open anyway"
        open.isEnabled = false
        val back = Button(this)
        back.text = "Go back"

        for (v in listOf(title, sub, count, back, open)) col.addView(v)

        back.setOnClickListener {
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            finish()
        }
        open.setOnClickListener {
            getSharedPreferences("reclaim", 0).edit().putLong("ok_$pkg", System.currentTimeMillis()).apply()
            finish()
        }
        object : CountDownTimer(10000, 1000) {
            override fun onTick(ms: Long) { count.text = ((ms / 1000) + 1).toString() }
            override fun onFinish() { count.text = "0"; open.isEnabled = true }
        }.start()
        setContentView(col)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {}
}
